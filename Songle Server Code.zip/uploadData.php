<?php

include 'serverCredentials.php';

// Get JSON Data

// Get Body
$postBody = file_get_contents('php://input');

// Decode JSON Input
// $data = json_decode($postBody);

// $score = $data->score;
$score = $_POST['score'];

// Add the score to the database
//Connect to server
$con = mysqli_connect($host, $dbUsername, $dbPassword, $db);
//Select Database
mysqli_select_db($con, $db);

mysqli_query($con, "INSERT INTO scores (score) VALUES ($score)") or die (mysqli_error($con));


$returnData = new stdClass();
$returnData->status = "Success";
$returnData->score = $score;

echo json_encode($returnData);

?>