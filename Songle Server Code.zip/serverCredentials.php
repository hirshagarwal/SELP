<?php
//AWS Server Connection
$db = "songle";
$host = "52.40.72.100";
$dbUsername = "h2micro";
$dbPassword = "76qMGJLDUHamNaWR";
?>