<?php

include 'serverCredentials.php';

// Add the score to the database
//Connect to server
$con = mysqli_connect($host, $dbUsername, $dbPassword, $db);
//Select Database
mysqli_select_db($con, $db);

// mysqli_query($con, "INSERT INTO scores (score) VALUES ($score)") or die (mysqli_error($con));
$results = mysqli_query($con, "SELECT * FROM scores") or die (mysql_error($con));
$highScore = 0;
$totalScores = 0;
$numScores = 0;
while($row = mysqli_fetch_array($results)){
	$score = $row['score'];
	if($score>$highScore){
		$highScore = $score;
	}
	$totalScores += $score;
	$numScores ++;
}



$returnData = new stdClass();
$returnData->status = "Success";
$returnData->topScore = $highScore;
$returnData->averageScore = $totalScores/$numScores;

echo json_encode($returnData);

?>